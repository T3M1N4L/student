"use client";
import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Mail,
  Settings as SettingsIcon,
  ChevronUp,
  Home,
  MessageCircle,
  Smartphone,
  BookCheck,
  FileText,
  Table2,
  CalendarDays,
  BookOpen,
  Table,
  School,
  History,
  LogOutIcon,
  ClipboardX,
  UserCircle,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getStoredCredentials, synergyPost } from "@/lib/clientApi";

// `working: false` marks pages not yet migrated to the new api
type NavItem = {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  working: boolean;
  module?: string;
};

const primaryNav: NavItem[] = [
  { name: "Home", href: "/", icon: Home, working: true },
  { name: "Gradebook", href: "/gradebook", icon: BookOpen, working: true, module: "showGradeBookModule" }, // prettier-ignore
  { name: "Schedule", href: "/schedule", icon: Table, working: true, module: "showCurrentScheduleModule" }, // prettier-ignore
  { name: "Calendar", href: "/calendar", icon: CalendarDays, working: false, module: "showCalenderModule" }, // prettier-ignore
  { name: "Attendance", href: "/attendance", icon: Table2, working: false, module: "showAttendanceModule" }, // prettier-ignore
  { name: "Mail", href: "/mail", icon: Mail, working: true, module: "showSynergyMailModule" }, // prettier-ignore
  { name: "Missing Work", href: "/missing", icon: ClipboardX, working: true, module: "showGradeBookModule" }, // prettier-ignore
  { name: "Documents", href: "/documents", icon: FileText, working: true, module: "showDocumentModule" }, // prettier-ignore
  { name: "Course History", href: "/history", icon: History, working: true, module: "showCourseHistoryModule" }, // prettier-ignore
  { name: "Test History", href: "/tests", icon: BookCheck, working: true, module: "showTestHistoryModule" }, // prettier-ignore
  { name: "School Information", href: "/school", icon: School, working: true, module: "showSchoolInformationModule" }, // prettier-ignore
];

// module visibility flags we read out of GetChildListData
const MODULE_FLAG_KEYS = [
  "showGradeBookModule",
  "showCurrentScheduleModule",
  "showCalenderModule",
  "showAttendanceModule",
  "showSynergyMailModule",
  "showDocumentModule",
  "showCourseHistoryModule",
  "showTestHistoryModule",
  "showSchoolInformationModule",
];

export function AppSidebar() {
  const pathname = usePathname();
  const [studentPhoto, setStudentPhoto] = React.useState<string>("");
  const [permId, setPermId] = React.useState<string>("");
  const [studentName, setStudentName] = React.useState<string>("");
  const [school, setSchool] = React.useState<string>("");
  const [moduleFlags, setModuleFlags] = React.useState<Record<
    string,
    boolean
  > | null>(null);
  const [quickStats, setQuickStats] = React.useState<{
    gpa: string;
    missing: number;
    gradedCourses: number;
    totalCourses: number;
    ts: number;
  } | null>(null);
  const [cumGPA, setCumGPA] = React.useState<{
    value: string;
    label: string;
  } | null>(null);
  const [nextPeriod, setNextPeriod] = React.useState<{
    period: number;
    courseTitle: string;
    room?: string;
    teacher?: string;
    timeUntil?: string;
    isNext: boolean;
  } | null>(null);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    const read = () => {
      try {
        const raw = localStorage.getItem("Student.quickStats");
        if (raw) {
          const parsed = JSON.parse(raw);
          setQuickStats((prev) =>
            !prev || prev.ts !== parsed.ts ? parsed : prev,
          );
        }
      } catch {}
      try {
        const raw = localStorage.getItem("Student.cumGPA");
        if (raw) {
          const parsed = JSON.parse(raw);
          if (
            typeof parsed?.rawPoints === "number" &&
            typeof parsed?.rawCredits === "number"
          ) {
            setCumGPA((prev) => (JSON.stringify(prev) === raw ? prev : parsed));
          }
        }
      } catch {}
    };
    read();
    const id = setInterval(read, 5000);
    return () => clearInterval(id);
  }, []);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      setStudentPhoto(localStorage.getItem("Student.studentPhoto") || "");
      setPermId(localStorage.getItem("Student.studentPermId") || "");
      setSchool(localStorage.getItem("Student.studentSchool") || "");
      const existingName = localStorage.getItem("Student.studentName") || "";
      if (existingName) setStudentName(existingName);
      const flags = localStorage.getItem("Student.moduleFlags");
      if (flags) setModuleFlags(JSON.parse(flags));
    } catch {}
  }, []);

  React.useEffect(() => {
    if (typeof window === "undefined") return;
    if (studentName && permId && school && studentPhoto && moduleFlags) return;

    const creds = getStoredCredentials();
    if (!creds) return;
    let aborted = false;

    (async () => {
      try {
        // GetChildListData returns the student's name, perm ID, school, grade
        // and photo (base64), plus the district's module visibility flags.
        const res = await synergyPost<{
          data?: {
            userFormattedName?: string;
            childrenList?: Array<{
              childName?: string;
              childPermID?: string;
              organizationName?: string;
              photo?: string;
            }>;
          } & Record<string, unknown>;
        }>("/api/synergy/children", creds);
        if (aborted) return;

        const data = res?.data;
        if (data) {
          const flags: Record<string, boolean> = {};
          for (const k of MODULE_FLAG_KEYS) {
            if (typeof data[k] === "boolean") flags[k] = data[k] as boolean;
          }
          if (Object.keys(flags).length) {
            setModuleFlags(flags);
            localStorage.setItem("Student.moduleFlags", JSON.stringify(flags));
          }
        }

        const child = res?.data?.childrenList?.[0];
        const nm = child?.childName || res?.data?.userFormattedName;
        if (nm && !studentName) {
          setStudentName(nm);
          localStorage.setItem("Student.studentName", nm);
        }
        if (child?.childPermID && !permId) {
          setPermId(child.childPermID);
          localStorage.setItem("Student.studentPermId", child.childPermID);
        }
        if (child?.organizationName && !school) {
          setSchool(child.organizationName);
          localStorage.setItem("Student.studentSchool", child.organizationName);
        }
        if (child?.photo && !studentPhoto) {
          setStudentPhoto(child.photo);
          localStorage.setItem("Student.studentPhoto", child.photo);
        }
      } catch {}
    })();

    return () => {
      aborted = true;
    };
  }, [studentName, permId, school, studentPhoto, moduleFlags]);

  React.useEffect(() => {
    if (typeof window === "undefined") return;

    const calculateNextPeriod = async () => {
      try {
        const creds = getStoredCredentials();
        if (!creds) {
          setNextPeriod(null);
          return;
        }

        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        const dayOfWeek = now.getDay();

        if (dayOfWeek === 0 || dayOfWeek === 6) {
          setNextPeriod(null);
          return;
        }

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const data = await synergyPost<any>("/api/synergy/schedule", creds);
        const todayClasses =
          data?.StudentClassSchedule?.TodayScheduleInfoData?.SchoolInfos
            ?.SchoolInfo?.Classes?.ClassInfo;

        if (!todayClasses) {
          return;
        }

        const parseTime = (timeStr?: string) => {
          if (!timeStr) return null;
          const match = timeStr.match(/^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i);
          if (!match) return null;

          const [, hours, minutes, period] = match;
          let h = parseInt(hours);
          const m = parseInt(minutes);

          if (period) {
            if (period.toUpperCase() === "PM" && h !== 12) h += 12;
            if (period.toUpperCase() === "AM" && h === 12) h = 0;
          }

          return h * 60 + m;
        };

        const classes = (
          Array.isArray(todayClasses) ? todayClasses : [todayClasses]
        )
          .map(
            (c: {
              _Period?: string;
              _ClassName?: string;
              _RoomName?: string;
              _TeacherName?: string;
              _StartTime?: string;
              _EndTime?: string;
            }) => ({
              period: Number(c._Period || 0),
              courseTitle: c._ClassName || "",
              room: c._RoomName || "",
              teacher: c._TeacherName || "",
              startTime: parseTime(c._StartTime),
              endTime: parseTime(c._EndTime),
            }),
          )
          .filter(
            (c) => c.courseTitle && c.startTime !== null && c.endTime !== null,
          )
          .sort((a, b) => a.startTime! - b.startTime! || a.period - b.period);

        if (classes.length === 0) {
          return;
        }

        const firstClass = classes[0];
        const lastClass = classes[classes.length - 1];
        const schoolStartTime = firstClass.startTime!;
        const schoolEndTime = lastClass.endTime!;

        if (currentTime < schoolStartTime || currentTime > schoolEndTime) {
          setNextPeriod(null);
          return;
        }

        for (let i = 0; i < classes.length; i++) {
          const classInfo = classes[i];
          const startTime = classInfo.startTime!;
          const endTime = classInfo.endTime!;

          if (currentTime < endTime) {
            const minutesUntil = Math.max(0, startTime - currentTime);
            const timeUntilText =
              minutesUntil === 0
                ? "Now"
                : minutesUntil < 60
                  ? `${minutesUntil}m`
                  : `${Math.floor(minutesUntil / 60)}h ${minutesUntil % 60}m`;

            setNextPeriod({
              period: classInfo.period,
              courseTitle: classInfo.courseTitle,
              room: classInfo.room,
              teacher: classInfo.teacher,
              timeUntil: timeUntilText,
              isNext: minutesUntil > 0,
            });
            return;
          }
        }

        setNextPeriod(null);
      } catch {
        setNextPeriod(null);
      }
    };

    calculateNextPeriod();
    const interval = setInterval(calculateNextPeriod, 3000);

    return () => clearInterval(interval);
  }, []);

  const isOnMockPage = pathname?.startsWith("/gradebook/mock");
  const displayPhoto = isOnMockPage ? "" : studentPhoto;
  const displayPermId = isOnMockPage ? "100001" : permId;
  const displaySchool = isOnMockPage ? "Lincoln High School" : school;
  const displayStudentName = isOnMockPage ? "Alex Johnson" : studentName;

  return (
    <Sidebar
      collapsible="icon"
      variant="sidebar"
      side="left"
      className="bg-white text-black dark:bg-zinc-900 dark:text-white"
    >
      <SidebarHeader className="gap-1">
        <div className="flex items-center justify-between h-8 px-2">
          <Link
            href="/"
            className="group-data-[collapsible=icon]:pt-1 pt-5 font-bold font-[Gosha] text-xl tracking-tight select-none"
          >
            <span className="inline group-data-[collapsible=icon]:hidden">
              student
            </span>
            <span className="hidden group-data-[collapsible=icon]:inline">
              S
            </span>
          </Link>
        </div>
      </SidebarHeader>
      <SidebarContent className="overflow-hidden">
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {primaryNav.map((item) => {
                // only surface Missing Work when there is missing work
                if (
                  item.href === "/missing" &&
                  (quickStats?.missing ?? 0) <= 0
                ) {
                  return null;
                }
                const active =
                  item.href === "/"
                    ? pathname === "/"
                    : pathname?.startsWith(item.href);
                const Icon = item.icon;
                const isOnMockPage = pathname?.startsWith("/gradebook/mock");
                const isGradebook = item.href === "/gradebook";
                const notWorking = item.working === false;
                const moduleHidden =
                  !!item.module &&
                  !!moduleFlags &&
                  moduleFlags[item.module] === false;
                const isDisabled =
                  (isOnMockPage && !isGradebook) || notWorking || moduleHidden;

                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                      asChild
                      isActive={!!active}
                      tooltip={
                        moduleHidden
                          ? `${item.name} — not enabled by your district`
                          : notWorking
                            ? `${item.name} — not available yet (API migration in progress)`
                            : isOnMockPage && !isGradebook
                              ? `${item.name} is disabled on mock page`
                              : item.name
                      }
                      className={
                        isDisabled
                          ? "opacity-50 cursor-not-allowed pointer-events-none"
                          : ""
                      }
                    >
                      <Link
                        href={item.href}
                        className={`flex items-center ${isDisabled ? "opacity-50" : ""}`}
                      >
                        <Icon className="shrink-0" />
                        <span>{item.name}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <div>
          {quickStats && quickStats.gradedCourses > 0 && (
            <>
              <SidebarSeparator />
              <SidebarGroup className="group-data-[collapsible=icon]:hidden hidden lg:block">
                <SidebarGroupLabel>Quick Stats</SidebarGroupLabel>
                <SidebarGroupContent>
                  <div className="grid grid-cols-1 gap-2 text-xs pl-1">
                    <div className="rounded-md border bg-sidebar-accent/50 p-2 flex flex-col gap-1">
                      <div className="flex items-baseline justify-between">
                        <p className="font-medium tracking-tight">
                          Semester GPA
                        </p>
                        <p className="text-sm font-semibold">
                          {quickStats.gpa}
                        </p>
                      </div>
                      {cumGPA && (
                        <div className="flex items-baseline justify-between">
                          <p className="font-medium tracking-tight">
                            {cumGPA.label}
                          </p>
                          <p className="text-sm font-semibold">
                            {cumGPA.value}
                          </p>
                        </div>
                      )}
                      <Link
                        href="/missing"
                        className="flex items-baseline justify-between hover:underline"
                      >
                        <p className="font-medium tracking-tight">Missing</p>
                        <p
                          className={`text-sm font-semibold ${
                            (quickStats.missing || 0) > 0 ? "text-red-600" : ""
                          }`}
                        >
                          {quickStats.missing}
                        </p>
                      </Link>
                      <div className="flex items-baseline justify-between text-[10px] pt-1 opacity-70 border-t mt-1">
                        <span>Courses</span>
                        <span>
                          {quickStats.gradedCourses}/{quickStats.totalCourses}
                        </span>
                      </div>
                    </div>
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            </>
          )}
          {nextPeriod && (
            <>
              <SidebarGroup className="group-data-[collapsible=icon]:hidden hidden lg:block">
                <SidebarGroupLabel>Next Period</SidebarGroupLabel>
                <SidebarGroupContent>
                  <div className="grid grid-cols-1 gap-2 text-xs pl-1">
                    <div className="rounded-md border bg-sidebar-accent/50 p-2 flex flex-col gap-1">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium tracking-tight truncate">
                            Period {nextPeriod.period}
                          </p>
                          <p className="text-[11px] text-muted-foreground truncate">
                            {nextPeriod.courseTitle}
                          </p>
                          {nextPeriod.room && (
                            <p className="text-[10px] text-muted-foreground/80 truncate">
                              Room {nextPeriod.room}
                            </p>
                          )}
                        </div>
                        <div className="text-right flex-shrink-0 ml-2">
                          <p
                            className={`text-sm font-semibold ${
                              nextPeriod.isNext
                                ? "text-blue-600"
                                : "text-green-600"
                            }`}
                          >
                            {nextPeriod.timeUntil}
                          </p>
                          <p className="text-[10px] text-muted-foreground">
                            {nextPeriod.isNext ? "starts" : "current"}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </SidebarGroupContent>
              </SidebarGroup>
            </>
          )}
        </div>
      </SidebarContent>
      <SidebarFooter>
        {(displayPhoto || displayPermId || displaySchool) && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild disabled={isOnMockPage}>
              <button
                className={`cursor-pointer w-full hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md mt-1 flex items-center gap-2 p-2 transition-colors group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:p-1 ${
                  isOnMockPage
                    ? "opacity-50 hover:bg-transparent cursor-not-allowed"
                    : ""
                }`}
                disabled={isOnMockPage}
              >
                {displayPhoto ? (
                  <Avatar>
                    <AvatarImage
                      className="rounded-full object-cover aspect-square group-data-[collapsible=icon]:size-8"
                      src={`data:image/png;base64,${displayPhoto}`}
                    />
                    <AvatarFallback>
                      {(
                        displayStudentName ||
                        displayPermId ||
                        displaySchool ||
                        "S"
                      ).slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                ) : (
                  <div className="size-9 shrink-0 rounded-full bg-sidebar-accent flex items-center justify-center text-[11px] font-medium uppercase group-data-[collapsible=icon]:size-10 group-data-[collapsible=icon]:text-sm">
                    {(
                      displayStudentName ||
                      displayPermId ||
                      displaySchool ||
                      "S"
                    ).slice(0, 2)}
                  </div>
                )}
                <div className="min-w-0 text-left group-data-[collapsible=icon]:hidden md:block">
                  {(displayStudentName || displayPermId) && (
                    <p className="truncate text-xs font-medium leading-tight">
                      {displayStudentName || displayPermId}
                    </p>
                  )}
                  {displaySchool && (
                    <p className="truncate text-[10px] text-muted-foreground leading-tight">
                      {displaySchool}
                    </p>
                  )}
                </div>
                <ChevronUp
                  className={`ml-auto size-4 opacity-60 group-data-[collapsible=icon]:hidden ${isOnMockPage ? "hidden" : ""}`}
                />
              </button>
            </DropdownMenuTrigger>

            <DropdownMenuContent align="start" side="top" className="w-52">
              <DropdownMenuLabel className="text-xs">Account</DropdownMenuLabel>
              <div className="px-2 pb-1 pt-0.5">
                {displayPermId && (
                  <p className="text-xs font-medium truncate">
                    ID: {displayPermId}
                  </p>
                )}
                {displaySchool && (
                  <p className="text-xs text-muted-foreground truncate">
                    {displaySchool}
                  </p>
                )}
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link
                  href="/account"
                  className="cursor-pointer flex items-center gap-2"
                >
                  <UserCircle className="size-4" />
                  <span>My Account</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link
                  href="/install"
                  className="cursor-pointer flex items-center gap-2"
                >
                  <Smartphone className="size-4" />
                  <span>Install Mobile App</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link
                  href="/feedback"
                  className="cursor-pointer flex items-center gap-2"
                >
                  <MessageCircle className="size-4" />
                  <span>Feedback</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link
                  href="/settings"
                  className="cursor-pointer flex items-center gap-2"
                >
                  <SettingsIcon className="size-4" />
                  <span>Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link
                  href="/logout"
                  className="cursor-pointer flex items-center gap-2"
                >
                  <LogOutIcon className="size-4" />
                  <span>Log out</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
