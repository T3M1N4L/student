"use client";
import { useEffect, useMemo, useState, useCallback } from "react";
import {
  loadCustomGPAScale,
  saveCustomGPAScale,
  resetCustomGPAScale,
  GPAScaleEntry,
  loadCustomGradeBounds,
  saveCustomGradeBounds,
  resetCustomGradeBounds,
  GradeBound,
  loadCalculateGradesEnabled,
  saveCalculateGradesEnabled,
  resetCalculateGradesEnabled,
  loadCacheDuration,
  saveCacheDuration,
  resetCacheDuration,
  clearGradebookCache,
  CACHE_DURATION_OPTIONS,
} from "@/utils/gradebook";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableHeader,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import Link from "next/link";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  useThemeCustomizer,
  THEMES,
  ThemeColor,
} from "@/components/ThemeProvider";
import { Copy, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const iconVariants = {
  hidden: { opacity: 0, scale: 0.5 },
  visible: { opacity: 1, scale: 1 },
};

const ORDER = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "F"];

const LOCALSTORAGE_KEYS = [
  // "Student.creds",
  "Student.zip",
  "Student.studentName",
  "Student.studentPhoto",
  "Student.studentPermId",
  "Student.studentSchool",
  "Student.reportingPeriodIndex",
  "Student.reportingPeriodEnd",
  "Student.quickStats",
  "Student.deletedMails",
  "Student.customGPAScale",
  "Student.customGradeBounds",
  "Student.calculateGrades",
  "Student.dontShowGradeCalcWarning",
  "Student.gradebookCache",
  "Student.cacheDurationMinutes",
  "theme-color",
  "tempUnit",
  "celsius",
  "umami.disabled",
];

export default function SettingsPage() {
  const { color, setColor } = useThemeCustomizer();
  const [entries, setEntries] = useState<GPAScaleEntry[]>([]);
  const [bounds, setBounds] = useState<GradeBound[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);
  const [showErrors, setShowErrors] = useState(false);
  const [calcGrades, setCalcGrades] = useState(false);
  const [hideGradeCalcWarning, setHideGradeCalcWarning] = useState(false);
  const [dontTrackMe, setDontTrackMe] = useState(false);
  const [tempUnit, setTempUnit] = useState<"fahrenheit" | "celsius" | "kelvin">(
    "fahrenheit",
  );
  const [cacheDuration, setCacheDuration] = useState<number>(30);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  const copyToClipboard = useCallback(async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedItem(label);
      setTimeout(() => setCopiedItem(null), 2000);
    } catch {
      console.error("Failed to copy to clipboard");
    }
  }, []);

  const getLocalStorageData = useCallback(() => {
    const data: Record<string, string | null> = {};
    for (const key of LOCALSTORAGE_KEYS) {
      data[key] = localStorage.getItem(key);
    }
    return data;
  }, []);

  const generateDebugInfo = useCallback(() => {
    const info = {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      screenSize: `${window.screen.width}x${window.screen.height}`,
      viewportSize: `${window.innerWidth}x${window.innerHeight}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      timestamp: new Date().toISOString(),
      localStorage: getLocalStorageData(),
    };
    return JSON.stringify(info, null, 2);
  }, [getLocalStorageData]);

  useEffect(() => {
    const scale = loadCustomGPAScale();
    setEntries(ORDER.map((letter) => ({ letter, value: scale[letter] })));
    setBounds(loadCustomGradeBounds());
    setCalcGrades(loadCalculateGradesEnabled());
    setHideGradeCalcWarning(
      !!localStorage.getItem("Student.dontShowGradeCalcWarning"),
    );
    setDontTrackMe(localStorage.getItem("umami.disabled") === "1");
    setCacheDuration(loadCacheDuration());
    const storedUnit = localStorage.getItem("tempUnit");
    if (
      storedUnit === "celsius" ||
      storedUnit === "fahrenheit" ||
      storedUnit === "kelvin"
    ) {
      setTempUnit(storedUnit);
    } else if (localStorage.getItem("celsius") === "1") {
      setTempUnit("celsius");
    } else {
      setTempUnit("fahrenheit");
    }
    setIsLoaded(true);
  }, []);

  const updateValue = (letter: string, val: string) => {
    setEntries((prev) =>
      prev.map((e) =>
        e.letter === letter ? { ...e, value: Number(val) || 0 } : e,
      ),
    );
    setSavedMsg("Saving...");
  };

  const updateBound = (letter: string, val: string) => {
    const num = Number(val);
    setBounds((prev) =>
      prev.map((b) =>
        b.letter === letter ? { ...b, min: isNaN(num) ? b.min : num } : b,
      ),
    );
    setSavedMsg("Saving...");
  };

  const validationErrors = useMemo(() => {
    const errs: string[] = [];
    for (const e of entries) {
      if (e.value < 0 || e.value > 5) {
        errs.push(`${e.letter} GPA must be between 0 and 5`);
      }
      if (!Number.isFinite(e.value)) {
        errs.push(`${e.letter} GPA must be a number`);
      }
    }
    const orderedBounds = ORDER.map(
      (letter) => bounds.find((b) => b.letter === letter) || { letter, min: 0 },
    );
    for (const b of orderedBounds) {
      if (b.min < 0 || b.min > 100 || !Number.isFinite(b.min)) {
        errs.push(`${b.letter} min% must be between 0 and 100`);
      }
    }
    for (let i = 0; i < orderedBounds.length - 1; i++) {
      const current = orderedBounds[i];
      const next = orderedBounds[i + 1];
      if (current.min < next.min) {
        errs.push(`Min % for ${current.letter} should be >= ${next.letter}`);
      }
      if (current.min === next.min) {
        errs.push(
          `Min % for ${current.letter} must be greater than ${next.letter}`,
        );
      }
    }
    const f = orderedBounds.find((b) => b.letter === "F");
    if (!f) errs.push("F grade bound missing");
    return errs;
  }, [entries, bounds]);

  useEffect(() => {
    if (!isLoaded) return;
    if (validationErrors.length > 0) {
      setShowErrors(true);
      setSavedMsg("Fix errors to save");
      return;
    }

    const timer = setTimeout(() => {
      saveCustomGPAScale(entries);
      const sanitized = bounds
        .filter((b) => b.letter)
        .map((b) => ({ ...b, min: Math.max(0, Math.min(100, b.min)) }))
        .sort((a, b) => b.min - a.min);
      saveCustomGradeBounds(sanitized);
      setSavedMsg("Saved");
      setTimeout(() => setSavedMsg(null), 2000);
    }, 500);

    return () => clearTimeout(timer);
  }, [entries, bounds, isLoaded, validationErrors]);

  const handleResetAll = () => {
    resetCustomGPAScale();
    resetCustomGradeBounds();
    resetCalculateGradesEnabled();
    resetCacheDuration();
    clearGradebookCache();
    localStorage.removeItem("Student.dontShowGradeCalcWarning");
    localStorage.removeItem("umami.disabled");
    localStorage.removeItem("celsius");
    localStorage.removeItem("tempUnit");
    const scale = loadCustomGPAScale();
    setEntries(ORDER.map((letter) => ({ letter, value: scale[letter] })));
    setBounds(loadCustomGradeBounds());
    setCalcGrades(loadCalculateGradesEnabled());
    setHideGradeCalcWarning(false);
    setDontTrackMe(false);
    setTempUnit("fahrenheit");
    setCacheDuration(loadCacheDuration());
    setSavedMsg("Reset to default");
    setTimeout(() => setSavedMsg(null), 1500);
  };

  const isInvalidLetter = (letter: string): boolean => {
    return (
      validationErrors.some((e) => e.startsWith(letter + " ")) ||
      validationErrors.some((e) => e.includes(" " + letter))
    );
  };

  return (
    <div className="p-8 space-y-6 min-h-screen dark:bg-zinc-900">
      <div>
        <p className="text-xl font-medium pb-3">Settings</p>
        <p className="text-sm text-zinc-500">
          Customize your student experience.
        </p>
      </div>
      <section className="space-y-4">
        <header>
          <h2 className="text-lg font-medium">Appearance</h2>
          <p className="text-xs text-zinc-500">
            Customize the look of Student to match your preferred theme.
          </p>
        </header>
        <div className="pl-5 pt-1 space-y-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:gap-8">
            <div className="space-y-2">
              <label className="text-sm font-medium block">Theme</label>
              <Select
                value={color}
                onValueChange={(val) => setColor(val as ThemeColor)}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select a theme" />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(THEMES) as ThemeColor[]).map((themeColor) => (
                    <SelectItem key={themeColor} value={themeColor}>
                      <div className="flex items-center gap-2">
                        <div
                          className="h-3 w-3 rounded-full"
                          style={{ backgroundColor: THEMES[themeColor].color }}
                        />
                        <span>{THEMES[themeColor].label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>
      <section className="space-y-4">
        <header>
          <h2 className="text-lg font-medium">Grades & GPA Configuration</h2>
          <p className="text-xs text-zinc-500">
            Edit thresholds based on your schools grading policy
          </p>
        </header>
        <div className="pl-5 pt-1">
          <div className="flex items-start gap-3 rounded">
            <Checkbox
              id="calc-grades"
              checked={calcGrades}
              onCheckedChange={(checked) => {
                const isChecked = checked === true;
                setCalcGrades(isChecked);
                saveCalculateGradesEnabled(isChecked);
              }}
            />
            <label
              htmlFor="calc-grades"
              className="text-sm leading-tight cursor-pointer select-none"
            >
              <span className="font-medium">Calculate Grades</span>
              <br />
              <span className="text-xs text-zinc-500 dark:text-zinc-400">
                When enabled, grades are recomputed locally using assignments
                and your custom bounds instead of accepting the portal&apos;s
                reported mark. This may be less accurate if your school uses
                hidden or excluded assignments, complex weighting, or other
                rules. GPA points are always calculated locally.
              </span>
            </label>
          </div>
          <div className="h-3" />
          <div className="flex items-start gap-3 rounded">
            <Checkbox
              id="hide-calc-warning"
              checked={hideGradeCalcWarning}
              onCheckedChange={(checked) => {
                const isChecked = checked === true;
                setHideGradeCalcWarning(isChecked);
                if (isChecked) {
                  localStorage.setItem(
                    "Student.dontShowGradeCalcWarning",
                    "true",
                  );
                } else {
                  localStorage.removeItem("Student.dontShowGradeCalcWarning");
                }
              }}
            />
            <label
              htmlFor="hide-calc-warning"
              className="text-sm leading-tight cursor-pointer select-none"
            >
              <span className="font-medium">
                Hide Grade Calculation Warnings
              </span>
              <br />
              <span className="text-xs text-zinc-500 dark:text-zinc-400">
                When enabled, warnings about grade calculation accuracy will be
                hidden.
              </span>
            </label>
          </div>
          <div className="h-3" />
          <Table className="min-w-[520px]">
            <TableHeader>
              <TableRow>
                <TableHead className="w-24">Letter</TableHead>
                <TableHead className="w-40">GPA Points</TableHead>
                <TableHead className="w-40">Min % (inclusive)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ORDER.map((letter) => {
                const entry = entries.find((e) => e.letter === letter);
                const bound = bounds.find((b) => b.letter === letter) || {
                  letter,
                  min: 0,
                };
                return (
                  <TableRow
                    key={letter}
                    className={isInvalidLetter(letter) ? "bg-red-50/60" : ""}
                  >
                    <TableCell className="font-medium">{letter}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        step="0.1"
                        min={0}
                        max={5}
                        value={entry?.value ?? 0}
                        onChange={(ev) => updateValue(letter, ev.target.value)}
                        className={`w-28 h-8 ${
                          entry &&
                          (entry.value < 0 ||
                            entry.value > 5 ||
                            !Number.isFinite(entry.value))
                            ? "border-red-500 focus-visible:ring-red-500"
                            : ""
                        }`}
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        step="0.1"
                        value={bound.min}
                        onChange={(ev) => updateBound(letter, ev.target.value)}
                        className={`w-28 h-8 ${
                          bound.min < 0 ||
                          bound.min > 100 ||
                          !Number.isFinite(bound.min)
                            ? "border-red-500 focus-visible:ring-red-500"
                            : ""
                        }`}
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          {showErrors && validationErrors.length > 0 && (
            <div className="text-sm text-red-600 space-y-1 border border-red-300 rounded p-2 bg-red-50">
              {validationErrors.map((e, i) => (
                <div key={i}>• {e}</div>
              ))}
            </div>
          )}
        </div>
        <div className="flex gap-3 items-center">
          <Button type="button" variant="outline" onClick={handleResetAll}>
            Reset to Default
          </Button>
          {savedMsg && (
            <span className="text-xs text-zinc-500 transition-opacity duration-500">
              {savedMsg}
            </span>
          )}
        </div>
      </section>
      <section className="space-y-4">
        <header>
          <h2 className="text-lg font-medium">Units & Preferences</h2>
          <p className="text-xs text-zinc-500">
            Customize units and display preferences
          </p>
        </header>
        <div className="pl-5 pt-1 space-y-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:gap-8">
            <div className="space-y-2">
              <label className="text-sm font-medium block">
                Gradebook Cache Duration
              </label>
              <Select
                value={String(cacheDuration)}
                onValueChange={(val) => {
                  const num = Number(val);
                  setCacheDuration(num);
                  saveCacheDuration(num);
                  clearGradebookCache();
                }}
              >
                <SelectTrigger className="">
                  <SelectValue placeholder="Select cache duration" />
                </SelectTrigger>
                <SelectContent>
                  {CACHE_DURATION_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={String(opt.value)}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                How long gradebook data is stored (cached) in the browser,
                before re-fetching. You can force a refresh by clicking the{" "}
                {'"'}Refresh{'"'} button to clear the cache and fetch fresh
                data.
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:gap-8">
            <div className="space-y-2">
              <label className="text-sm font-medium block">
                Temperature Unit
              </label>
              <Select
                value={tempUnit}
                onValueChange={(val) => {
                  if (
                    val === "celsius" ||
                    val === "fahrenheit" ||
                    val === "kelvin"
                  ) {
                    setTempUnit(val);
                    localStorage.setItem("tempUnit", val);
                    if (val === "celsius") {
                      localStorage.setItem("celsius", "1");
                    } else {
                      localStorage.removeItem("celsius");
                    }
                  }
                }}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select temperature unit" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                  <SelectItem value="celsius">Celsius (°C)</SelectItem>
                  <SelectItem value="kelvin">Kelvin (K)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>
      <section className="space-y-4">
        <header>
          <h2 className="text-lg font-medium">Privacy & data</h2>
          <p className="text-xs text-zinc-500">
            Manage your privacy and data preferences
          </p>
        </header>
        <div className="pl-5 pt-1">
          <div className="flex items-start gap-3 rounded">
            <Checkbox
              id="dont-track-me"
              checked={dontTrackMe}
              onCheckedChange={(checked) => {
                const isChecked = checked === true;
                setDontTrackMe(isChecked);
                if (isChecked) {
                  localStorage.setItem("umami.disabled", "1");
                } else {
                  localStorage.removeItem("umami.disabled");
                }
              }}
            />
            <label
              htmlFor="dont-track-me"
              className="text-sm leading-tight cursor-pointer select-none"
            >
              <span className="font-medium">Disable Umami Analytics</span>
              <br />
              <span className="text-xs text-zinc-500 dark:text-zinc-400">
                We use <Link href="https://umami.is">Umami</Link>, a privacy
                focused analytics tool, to gather anonymous statistics. All data
                is anonymous and there is no identifable information or
                password/grades passed. Checking this signifies you want to
                opt-out.
              </span>
            </label>
          </div>
        </div>
      </section>
      <section className="space-y-4">
        <header>
          <h2 className="text-lg font-medium">Developer & Debug</h2>
          <p className="text-xs text-zinc-500">
            Tools for debugging and development. Use with caution.
          </p>
        </header>
        <div className="pl-5 pt-1 space-y-6">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-sm">Copy Debug Info</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(generateDebugInfo(), "debug-info")}
              >
                <AnimatePresence mode="wait" initial={false}>
                  {copiedItem === "debug-info" ? (
                    <motion.span key="check" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Check className="h-4 w-4" />
                    </motion.span>
                  ) : (
                    <motion.span key="copy" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Copy className="h-4 w-4" />
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            </div>
            <p className="text-sm text-zinc-500">
              Copy all debug information including localStorage data, browser
              info, and settings.{" "}
              <span className="font-semibold">
                Do not share this information with anyone you do not trust. It
                contains info to access your account. It contains your grades
                and other student info. It does not contain credentials.
              </span>
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Copy localStorage</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  copyToClipboard(
                    JSON.stringify(getLocalStorageData(), null, 2),
                    "localStorage",
                  )
                }
              >
                <AnimatePresence mode="wait" initial={false}>
                  {copiedItem === "localStorage" ? (
                    <motion.span key="check" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Check className="h-4 w-4" />
                    </motion.span>
                  ) : (
                    <motion.span key="copy" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Copy className="h-4 w-4" />
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            </div>
            <p className="text-sm text-zinc-500">
              Copy all Student localStorage data as JSON.{" "}
              <span className="font-semibold">
                Do not share this information with anyone you do not trust. It
                contains your grades and other student info. It does not contain
                credentials.
              </span>
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <h3 className="font-medium text-sm">Copy Credentials</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  copyToClipboard(
                    localStorage.getItem("Student.creds") || "No credentials",
                    "creds",
                  )
                }
              >
                <AnimatePresence mode="wait" initial={false}>
                  {copiedItem === "creds" ? (
                    <motion.span key="check" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Check className="h-4 w-4" />
                    </motion.span>
                  ) : (
                    <motion.span key="copy" variants={iconVariants} initial="hidden" animate="visible" exit="hidden">
                      <Copy className="h-4 w-4" />
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            </div>
            <p className="text-sm text-zinc-500">
              Copy your stored credentials.{" "}
              <span className="font-semibold">
                Do not share this information with anyone you do not trust. It
                contains info to access your account.
              </span>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
